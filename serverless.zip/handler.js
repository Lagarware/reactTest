'use strict';
// functions contains all functions needed
var functions = require('./functions.js')

module.exports.lambdaV2 = async (event) => {
    var req = JSON.parse(event.body)
    let responseObject = functions.validate(req) //this function builds the response after validating
    if(responseObject.text){
      functions.sendEmail(req) //this function send email
    }
    const response = {
      statusCode: 200,
       headers: {
          "Content-Type" : "application/json",
          "Access-Control-Allow-Headers" : "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
          "Access-Control-Allow-Methods" : "POST",
          "Access-Control-Allow-Credentials" : true,
          "Access-Control-Allow-Origin" : "*",
          "X-Requested-With" : "*"
      },
      body: JSON.stringify(responseObject),
  };
  
  return response;
    
};
