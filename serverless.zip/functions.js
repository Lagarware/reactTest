var aws =  require("aws-sdk");
var ses = new aws.SES({region:"us-east-1"});
exports.validate = function (req) {
  let resp;
  let errors = [];
  if (req.payTime == 0) {
    req.payTime = 12;
  }
  if (!req.email || req.email.length == 0) {
    errors.push({ message: "Email es requerido", field: "email" });
  }
  if (!req.name || req.name.length == 0) {
    errors.push({ message: "El nombre es requerido", field: "name" });
  }
  if (!req.sector || req.sector == 0) {
    errors.push({ message: "Debe incluir el sector", field: "sector" });
  }
  if (!req.amount || req.amount < 100 || req.amount > 2000) {
    errors.push({
      message: "El monto debe incluirse y el rango es entre 100 y 2000",
      field: "amount",
    });
  }
  if (!req.workYears || req.workYears == 0) {
    errors.push({
      message: "Años laborados no puede venir en cero",
      field: "workYears",
    });
  }

  if (errors.length > 0) {
    resp = { errors: errors };
  } else {
    //calculate payment, number of payments and response message
    var totInterest = req.amount * 0.018;
    var loan = req.amount + totInterest;
    var payment, mode, payments;
    if (req.frequency == 1) {
      //monthly
      payment = (loan / req.payTime).toFixed(2);
      payments = req.payTime;
      mode = "meses";
    } else {
      //biweekly
      payment = (loan / (req.payTime / 2)).toFixed(2);
      payments = req.payTime * 2;
      mode = "quincenas";
    }
    resp = {
      text: `Para un crédito de ${req.amount}, la cuota será de ${payment} por un número de cuotas de ${payments}`,
    };
  }
  return resp;
}
exports.sendEmail = function (req){
    var params = {
        Destination: {
          ToAddresses: ["cmora9@me.com,sergio9@mawi.io"],//sergio9@mawi.io
        },
        Message: {
          Body: {
            Text: { Data: `Solicitud de préstamo ${req.name}, email: ${req.email}, por un monto de ${req.amount}` },
          },
    
          Subject: { Data: "Test Email" },
        },
        Source: "carloslmram@gmail.com",
      };
     
      return ses.sendEmail(params).promise()
}